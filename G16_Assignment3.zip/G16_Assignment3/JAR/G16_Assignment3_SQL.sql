CREATE DATABASE  IF NOT EXISTS `myfuel` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `myfuel`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: myfuel
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acquires`
--

DROP TABLE IF EXISTS `acquires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acquires` (
  `acquireID` int(11) NOT NULL AUTO_INCREMENT,
  `amount` int(11) DEFAULT NULL,
  `stationID` int(11) DEFAULT NULL,
  `fuelType` varchar(45) DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  PRIMARY KEY (`acquireID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acquires`
--

LOCK TABLES `acquires` WRITE;
/*!40000 ALTER TABLE `acquires` DISABLE KEYS */;
INSERT INTO `acquires` VALUES (1,100,111,'Benzine95',4,12,2015),(2,200,111,'Benzine95',30,12,2015),(3,100,222,'Benzine95',1,1,2016),(4,1000,111,'Benzine95',5,1,2016),(5,200,222,'Benzine95',15,1,2016),(6,2000,111,'Diesel',16,1,2016),(7,150,111,'Diesel',17,1,2016),(14,700,111,'Benzine95',17,1,2016),(15,200,111,'Benzine95',17,1,2016),(16,50,111,'Benzine95',18,1,2016),(17,2000,111,'Motors',18,1,2016),(18,2000,222,'Diesel',18,1,2016);
/*!40000 ALTER TABLE `acquires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign` (
  `CampaignId` int(11) NOT NULL AUTO_INCREMENT,
  `campaigName` varchar(45) DEFAULT NULL,
  `discountPercent` int(11) DEFAULT NULL,
  `startDay` date DEFAULT NULL,
  `endDay` date DEFAULT NULL,
  `startHour` time DEFAULT NULL,
  `endtHour` time DEFAULT NULL,
  `campaignStatus` varchar(45) DEFAULT 'Not approved',
  PRIMARY KEY (`CampaignId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign`
--

LOCK TABLES `campaign` WRITE;
/*!40000 ALTER TABLE `campaign` DISABLE KEYS */;
INSERT INTO `campaign` VALUES (4,'Day',15,'2013-08-30','2013-08-30','10:15:00','10:15:00','Not approved'),(6,'Night',12,'2016-01-01','2016-01-15','01:00:00','03:00:00','Not approved');
/*!40000 ALTER TABLE `campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `car`
--

DROP TABLE IF EXISTS `car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `car` (
  `ownerid` int(11) NOT NULL,
  `licenseplatenumber` varchar(45) NOT NULL,
  `fueltype` varchar(45) NOT NULL,
  `carytype` varchar(45) NOT NULL,
  `carNFC` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`licenseplatenumber`),
  KEY `ownerid_idx` (`ownerid`),
  CONSTRAINT `ownerid` FOREIGN KEY (`ownerid`) REFERENCES `customer` (`customeId`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car`
--

LOCK TABLES `car` WRITE;
/*!40000 ALTER TABLE `car` DISABLE KEYS */;
INSERT INTO `car` VALUES (123,'53-535-55','Benzine95','automatic','false');
/*!40000 ALTER TABLE `car` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customeId` int(11) NOT NULL,
  `customerFirstName` varchar(45) NOT NULL,
  `customerLastName` varchar(45) NOT NULL,
  `customerEmail` varchar(45) NOT NULL,
  `customerAddress` varchar(45) NOT NULL,
  `creditCardNumber` varchar(45) DEFAULT NULL,
  `membershiptype` varchar(45) NOT NULL,
  `payment` varchar(45) NOT NULL,
  `customerPhone` varchar(45) NOT NULL,
  `rank` int(11) DEFAULT '1',
  PRIMARY KEY (`customeId`),
  KEY `customerid_idx` (`customeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (123,'sda','dsa','dsa@bjdsk.com','dhsakj','123456','Refueling occur','Cash','0973737732',1),(234,'ads','sda','sda@asd.com','asdasd','132131','Subscription multiple car','Cash','0973737432',1),(345,'dsa','ads','asdas@asdlk.com','asdasdasd','312321','Full subscription','CreditCard','0973737731',1);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customerhistory`
--

DROP TABLE IF EXISTS `customerhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customerhistory` (
  `customerHistoryId` int(11) NOT NULL AUTO_INCREMENT,
  `customerIdHistory` int(11) NOT NULL,
  `ordersTime` int(11) NOT NULL,
  `fuelTypeOrder` varchar(45) NOT NULL,
  `customerType` varchar(45) DEFAULT NULL COMMENT '?????????????',
  PRIMARY KEY (`customerHistoryId`),
  KEY `customerIdHistory_idx` (`customerIdHistory`),
  CONSTRAINT `customerIdHistory` FOREIGN KEY (`customerIdHistory`) REFERENCES `customer` (`customeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customerhistory`
--

LOCK TABLES `customerhistory` WRITE;
/*!40000 ALTER TABLE `customerhistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `customerhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fuelcompany`
--

DROP TABLE IF EXISTS `fuelcompany`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuelcompany` (
  `fuelCompanyId` int(11) NOT NULL AUTO_INCREMENT,
  `fuelCompanyName` varchar(45) NOT NULL,
  PRIMARY KEY (`fuelCompanyId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuelcompany`
--

LOCK TABLES `fuelcompany` WRITE;
/*!40000 ALTER TABLE `fuelcompany` DISABLE KEYS */;
INSERT INTO `fuelcompany` VALUES (1,'paz'),(2,'Delek');
/*!40000 ALTER TABLE `fuelcompany` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fuelstation`
--

DROP TABLE IF EXISTS `fuelstation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuelstation` (
  `fuelStationId` int(11) NOT NULL AUTO_INCREMENT,
  `stationMenagerID` int(11) NOT NULL,
  `stationOfCompanyId` int(11) NOT NULL,
  `stsationName` varchar(45) NOT NULL,
  `Benzine95` int(11) NOT NULL,
  `Motors` int(11) NOT NULL,
  `Diesel` int(11) NOT NULL,
  `minLevelAmount` int(11) NOT NULL,
  PRIMARY KEY (`fuelStationId`),
  UNIQUE KEY `stationMenagerID_UNIQUE` (`stationMenagerID`),
  UNIQUE KEY `stsationName_UNIQUE` (`stsationName`),
  KEY `stationMenagerID_idx` (`stationMenagerID`),
  KEY `stationOfCompanyId_idx` (`stationOfCompanyId`),
  CONSTRAINT `stationMenagerID` FOREIGN KEY (`stationMenagerID`) REFERENCES `worker` (`workerid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `stationOfCompanyId` FOREIGN KEY (`stationOfCompanyId`) REFERENCES `fuelcompany` (`fuelCompanyId`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuelstation`
--

LOCK TABLES `fuelstation` WRITE;
/*!40000 ALTER TABLE `fuelstation` DISABLE KEYS */;
INSERT INTO `fuelstation` VALUES (111,3,1,'abo',4235,6500,5250,500),(222,13,1,'bbo',200,300,2100,700);
/*!40000 ALTER TABLE `fuelstation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice` (
  `invoiceId` int(11) NOT NULL AUTO_INCREMENT,
  `stationId` int(11) NOT NULL,
  `paymentDate` date DEFAULT NULL,
  `orderDate` date DEFAULT NULL,
  `price` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `fuelType` varchar(45) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`invoiceId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (1,111,NULL,'2015-12-26',4900,234,700,'Benzine95',NULL),(2,222,NULL,'2015-12-28',2200,234,320,'Benzine95',NULL),(3,111,NULL,'2016-01-15',1500,123,220,'Diesel',NULL),(4,111,NULL,'2016-01-17',70,123,5,'Motors',NULL),(5,111,NULL,'2015-12-20',120,234,14,'Benzine95',NULL),(6,222,NULL,'2016-01-02',150,345,18,'Diesel',NULL),(7,111,NULL,'2016-01-07',170,345,22,'Benzine95',NULL),(8,111,'2016-01-18','2016-01-18',63,1,12,'Diesel',NULL),(9,222,'2016-01-18','2016-01-18',340,1,65,'Benzine95',NULL),(10,999,'2016-01-02','2016-01-02',167,1,32,'HomeFuel',NULL),(11,999,'2016-01-18','2016-01-18',1679,5,321,'HomeFuel',NULL),(12,999,'2016-01-18','2016-01-18',3400,5,650,'HomeFuel',NULL);
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordercarfuel`
--

DROP TABLE IF EXISTS `ordercarfuel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordercarfuel` (
  `orderId` int(11) NOT NULL AUTO_INCREMENT,
  `buyerId` int(11) NOT NULL,
  `licensePlateNumber` varchar(45) NOT NULL,
  `FuelStationId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `fuelType` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`orderId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordercarfuel`
--

LOCK TABLES `ordercarfuel` WRITE;
/*!40000 ALTER TABLE `ordercarfuel` DISABLE KEYS */;
INSERT INTO `ordercarfuel` VALUES (1,123,'123',111,400,NULL),(2,123,'2323',111,700,'Benzine95'),(3,333,'321',111,700,'Benzine95'),(4,1,'12',111,12,'Diesel'),(5,1,'23',222,65,'Benzine95');
/*!40000 ALTER TABLE `ordercarfuel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderhomefuel`
--

DROP TABLE IF EXISTS `orderhomefuel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderhomefuel` (
  `orderId` int(11) NOT NULL AUTO_INCREMENT,
  `invitedById` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `addressToSupply` varchar(45) NOT NULL,
  `supplyDate` date NOT NULL,
  `supplyTime` varchar(45) NOT NULL,
  `orderType` varchar(45) NOT NULL COMMENT 'there is a 3 types of reder 1.fast 2.under 800 3.over 800 ',
  PRIMARY KEY (`orderId`),
  KEY `customerId_idx` (`invitedById`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderhomefuel`
--

LOCK TABLES `orderhomefuel` WRITE;
/*!40000 ALTER TABLE `orderhomefuel` DISABLE KEYS */;
INSERT INTO `orderhomefuel` VALUES (1,1,32,'sdf','2016-01-02','22:00','Under 600'),(2,5,321,'Ort braude','2016-01-18','10:00','Under 600'),(3,5,650,'Hertel 67 haifa','2016-01-18','10:00','600-800');
/*!40000 ALTER TABLE `orderhomefuel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quarterreport`
--

DROP TABLE IF EXISTS `quarterreport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quarterreport` (
  `ReportQuarterId` int(11) NOT NULL AUTO_INCREMENT,
  `totalIncome` double NOT NULL,
  `Benzine95` varchar(45) DEFAULT NULL,
  `diesel` varchar(45) DEFAULT NULL,
  `Motors` varchar(45) DEFAULT NULL,
  `Quarter` varchar(45) DEFAULT NULL,
  `year` int(10) DEFAULT NULL,
  PRIMARY KEY (`ReportQuarterId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quarterreport`
--

LOCK TABLES `quarterreport` WRITE;
/*!40000 ALTER TABLE `quarterreport` DISABLE KEYS */;
/*!40000 ALTER TABLE `quarterreport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rates`
--

DROP TABLE IF EXISTS `rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rates` (
  `maxMotorsFuel` float NOT NULL,
  `Motors` float DEFAULT '0',
  `maxbenzine95` float NOT NULL,
  `Benzine95` float DEFAULT '0',
  `maxDiesel` float NOT NULL,
  `Diesel` float DEFAULT '0',
  `maxHomefuel` float NOT NULL,
  `HomeFuel` float DEFAULT '0',
  `RatesId` int(11) NOT NULL,
  PRIMARY KEY (`RatesId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rates`
--

LOCK TABLES `rates` WRITE;
/*!40000 ALTER TABLE `rates` DISABLE KEYS */;
INSERT INTO `rates` VALUES (5.36,5.23,5.36,5.23,5.36,5.23,5.36,5.23,1);
/*!40000 ALTER TABLE `rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registretionform`
--

DROP TABLE IF EXISTS `registretionform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registretionform` (
  `registretionFormId` int(11) NOT NULL AUTO_INCREMENT,
  `addedByWorkerId` int(11) NOT NULL,
  `customerType` char(10) NOT NULL,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `address` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `creditCard` varchar(45) NOT NULL,
  `cashPaymentOption` int(10) unsigned zerofill NOT NULL,
  `purchasePlan` varchar(45) NOT NULL,
  PRIMARY KEY (`registretionFormId`),
  UNIQUE KEY `CustomerId_UNIQUE` (`customerId`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `addedByWorkerId_idx` (`addedByWorkerId`),
  CONSTRAINT `addedByWorkerId` FOREIGN KEY (`addedByWorkerId`) REFERENCES `worker` (`workerid`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registretionform`
--

LOCK TABLES `registretionform` WRITE;
/*!40000 ALTER TABLE `registretionform` DISABLE KEYS */;
/*!40000 ALTER TABLE `registretionform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salereactionreport`
--

DROP TABLE IF EXISTS `salereactionreport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salereactionreport` (
  `saleReactionReportID` int(11) NOT NULL AUTO_INCREMENT,
  `numOfCutomersOnSale` int(11) NOT NULL,
  `TBD` varchar(45) NOT NULL COMMENT 'what is TBD?',
  PRIMARY KEY (`saleReactionReportID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salereactionreport`
--

LOCK TABLES `salereactionreport` WRITE;
/*!40000 ALTER TABLE `salereactionreport` DISABLE KEYS */;
/*!40000 ALTER TABLE `salereactionreport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stationfuelorder`
--

DROP TABLE IF EXISTS `stationfuelorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stationfuelorder` (
  `stationFuelOrderId` int(11) NOT NULL AUTO_INCREMENT,
  `stationId` int(11) NOT NULL,
  `orderAmount` int(11) NOT NULL,
  `supplyer` varchar(45) NOT NULL,
  `fuelType` varchar(45) NOT NULL,
  PRIMARY KEY (`stationFuelOrderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This table saves all the fuel stations order then they come to the lovest level';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stationfuelorder`
--

LOCK TABLES `stationfuelorder` WRITE;
/*!40000 ALTER TABLE `stationfuelorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `stationfuelorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `supplierId` int(11) NOT NULL,
  `supplierName` varchar(45) NOT NULL,
  PRIMARY KEY (`supplierId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `username` char(20) NOT NULL,
  `userpw` char(10) NOT NULL,
  `userlogstatus` int(11) NOT NULL,
  `usertype` char(10) NOT NULL,
  `userid` int(10) NOT NULL,
  `role` char(20) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='user id must be done here because if it will be done in customer or worker table my be a duplication ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('tal','1234',0,'customer',1,''),('arthur','1234',0,'worker',2,'MarketingManager'),('maor','1234',0,'worker',3,'StationManager'),('avi','1234',0,'customer',5,''),('MW','1234',0,'worker',6,'MarketingWorker'),('Shimon','1234',0,'customer',7,''),('omri','1234',0,'worker',8,'CEO'),('David','1234',0,'worker',13,'StationManager'),('Yosi','1234',0,'worker',14,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker`
--

DROP TABLE IF EXISTS `worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker` (
  `employeenumber` int(11) NOT NULL AUTO_INCREMENT,
  `workerid` int(11) NOT NULL,
  `workerfirstname` varchar(45) NOT NULL,
  `workerlastname` varchar(45) NOT NULL,
  `workeremail` varchar(45) DEFAULT NULL,
  `Affiliation` varchar(45) NOT NULL,
  PRIMARY KEY (`employeenumber`),
  UNIQUE KEY `employeenumber_UNIQUE` (`employeenumber`),
  UNIQUE KEY `workeremail_UNIQUE` (`workeremail`),
  KEY `workerid_idx` (`workerid`),
  CONSTRAINT `workerid` FOREIGN KEY (`workerid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker`
--

LOCK TABLES `worker` WRITE;
/*!40000 ALTER TABLE `worker` DISABLE KEYS */;
INSERT INTO `worker` VALUES (1,8,'Omri','Couri','Omri.Couri@gmail.com','administration'),(2,2,'Arthur','Boim','Arthur.boim@gmail.com','administration'),(3,6,'Ron','Cohen','Ron.Cohen@gmail.com','administration'),(4,3,'Maor','Halpern','Maor.Halpern@gmail.com','station'),(5,13,'David','Hamelech','David@gmail.com','station');
/*!40000 ALTER TABLE `worker` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-01-18  4:17:03
