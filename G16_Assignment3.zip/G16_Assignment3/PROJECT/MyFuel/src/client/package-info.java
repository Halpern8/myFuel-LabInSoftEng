/**
 * this package is for everything related to client.
 * runs methods to get messages from server.
 * runs Client
 * @author G16
 */

package client;