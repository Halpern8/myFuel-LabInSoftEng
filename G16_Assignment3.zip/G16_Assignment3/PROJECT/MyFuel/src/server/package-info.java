/**
 * this package is used mainly for opening a server connection to a DataBase
 * and listening port for clients. in addition it stores all of the server methods
 * which connects the client with the server and then lets the server use the DB
 * and in some cases sent back data to client from DB
 * @author G16
 */
package server;
