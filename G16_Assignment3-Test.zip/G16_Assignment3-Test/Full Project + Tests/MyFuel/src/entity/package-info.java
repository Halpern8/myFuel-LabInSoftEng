/**
 * entity package: this package contains all of the entities for MyFuel.
 * these classes contains fields in which instances of the classes fill with
 * data from DB or data to be inserted into the DB.
 * @author G16
 */
package entity;
