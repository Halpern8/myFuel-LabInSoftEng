/**
 * GUI package: this package contains all of the GUIs in MyFuel.
 * GUI fields(labels,buttons,actionListeners and more...)
 * @author G16
 */
package gui;
