package FitTest;

import fit.ActionFixture;

public class actionClass {
	
    public void chcekFuelOrder(int customerId , String licensePlateNumber, int quantity , String fuel_type , int fuel_stationId) {
    	
    	
        
   }




}
