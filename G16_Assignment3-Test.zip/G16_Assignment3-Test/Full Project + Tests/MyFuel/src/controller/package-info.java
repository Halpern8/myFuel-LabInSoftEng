/**
 * controller package: this package contains all of the controllers for MyFuel.
 * these controllers are used to connect the GUI with functionality, provides easy
 * access between client's data and DB data. 
 * @author G16
 */
package controller;
