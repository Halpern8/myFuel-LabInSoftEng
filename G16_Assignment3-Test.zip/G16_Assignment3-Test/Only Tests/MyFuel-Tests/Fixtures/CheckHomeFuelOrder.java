package Fixtures;

import java.util.IllegalFormatException;

import Entities.OrderHomeFuel;
import Entities.Customer;
import Entities.FuelStation;
import Entities.Rates;
import fit.ActionFixture;

public class CheckHomeFuelOrder extends ActionFixture {	
	OrderHomeFuel temp = null;
	
	// rates
	Rates rates = null;
	
	public void setUp(){
		temp = new OrderHomeFuel();
		rates = new Rates();
		rates.setMaxHomeFuel((float)5.5);
	}
	
	public void amount(int qty){
		temp.setQuantity(qty);
	}
	
	public void urgent(int num){
		temp.setUrgent(num);
	}
	
	public double chargeTest() {
		return temp.makeOrder(temp,rates);
		
	}

}
