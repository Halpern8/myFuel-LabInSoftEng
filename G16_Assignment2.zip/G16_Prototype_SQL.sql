create database G16_ass_2;
use G16_ass_2;

CREATE TABLE `OurFiles` (
	`fileName` VARCHAR(20) NOT NULL,
	`drive` VARCHAR(20),
	PRIMARY KEY  (`fileName`)
);

insert into OurFiles values ('testTable1', 'C:');
